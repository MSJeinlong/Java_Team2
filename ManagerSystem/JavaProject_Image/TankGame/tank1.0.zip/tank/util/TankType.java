package game.tank.util;

public enum TankType {
	MAIN_TANK,HEAVY_TANK,LIGHT_TANK
}
